const canvas = document.getElementById('mycanvas');
const context = canvas.getContext('2d');


canvas.width = window.innerWidth;
canvas.height = window.innerHeight;


const centerX = canvas.width / 2;
const centerY = canvas.height / 2;
const radius = Math.min(centerX, centerY) * 0.8;
context.beginPath();
context.arc(centerX, centerY, radius, 0, 2 * Math.PI,);
context.fillStyle = 'blue';
context.fill();
